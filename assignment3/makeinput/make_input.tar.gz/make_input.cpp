#include <iostream>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[]) {
	char file_name[200];
	strcpy(file_name, argv[1]);
	int size = atoi(argv[2]);
	int seed = atoi(argv[3]);
	int data = (argc == 5 ? atoi(argv[4]) : 0);

	srand(seed);
	freopen(file_name, "w", stdout);
	
	for (int i = 0; i < size; ++i) {
		int rand_val = (rand() % 128);
		if (rand_val == 26) --i;
		else if (data == 1) {
			if ((rand_val >= 48 && rand_val <= 57) || (rand_val >= 65 && rand_val <= 90) || (rand_val >= 97 && rand_val <= 122)) cout << (char) rand_val;
			else --i;
		}
		else if (data == 2) {
			for (int j = 0; j < size; ++j)
				cout << (char) rand_val;
			break;
		}
		else cout << (char) rand_val;
	}
}
