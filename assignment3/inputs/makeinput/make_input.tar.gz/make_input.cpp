#include <iostream>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cstdlib>
using namespace std;

int main(int argc, char* argv[]) {
	char file_name[200];
	strcpy(file_name, argv[1]);
	int size = atoi(argv[2]);
	int seed = atoi(argv[3]);

	srand(seed);
	freopen(file_name, "w", stdout);
	
	for (int i = 0; i < size; ++i) {
		int rand_val = (rand() % 128);
		if (rand_val == 26) --i;
		else cout << (char) rand_val;
	}
}
