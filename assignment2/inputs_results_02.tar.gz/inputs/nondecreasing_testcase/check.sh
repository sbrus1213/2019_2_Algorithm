# result 파일 시간만 모아보기 위한 쉘프로그램
INPUTS=$(ls result_*)
for input in $INPUTS
do
	echo $input
	echo $(sed -n 4p $input)

done
